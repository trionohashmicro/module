# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _

class account_payment(models.Model):
    _name = 'account.payment'
    _inherit = ['account.payment', 'mail.thread', 'ir.needaction_mixin']

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:    

    
