# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name' : 'Register Payment for Multiple Vendors Bills & Customer Invoices',
    'version' : '1.0',
    'category': 'Accounting',
    'sequence': 1,
    'author' : 'HashMicro/ Amit Patel',
    'website': 'www.hashmicro.com',
    'description' : """
        Register Payment for Multiple Vendors Bills & Customer Invoices
    """,
    'depends' : ['base','account'],
    'data' : [
          'views/account_payment.xml',
          'wizard/multiple_register_payments.xml',
     ],
    'demo' : [],
    'test': [],
    'application': True,
    'installable': True,
    'auto_install': False,
    'images': [],
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
