# -*- coding: utf-8 -*-
from odoo import models, fields, api, tools
from datetime import datetime
import xlwt
import base64
import tempfile
import os
from StringIO import StringIO
from xlrd import open_workbook, xldate_as_tuple
import tempfile
import binascii
import re
from odoo.exceptions import ValidationError
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT
import pytz
from dateutil import tz

class full_inv_adjustment_import(models.TransientModel):
    _name = 'full.inv.adjustment.import'
    _description = 'Full Inv Adjustment Import'

    import_file = fields.Binary("Import File")
    import_name = fields.Char('Import Name', size=64)
    export_file = fields.Binary("Export File")
    export_name = fields.Char('Export Name', size=64)
    is_export = fields.Boolean('Export')

    @api.multi
    def download_inv_adjustment_template(self):
        file_name = 'FullInvAdjustmentTemplate.xls'
        workbook = xlwt.Workbook(encoding="UTF-8")
        worksheet = workbook.add_sheet('Full Inv Adjustment Template')

        style = xlwt.easyxf('font:bold True, name Arial;align: horiz left;')

        worksheet.col(0).width = 11000
        worksheet.col(1).width = 8000
        worksheet.col(2).width = 6000
        worksheet.col(3).width = 6000
        worksheet.col(4).width = 4000
        worksheet.col(5).width = 6000
        worksheet.col(6).width = 8000

        worksheet.write(0, 0, 'Inventory Reference', style)
        worksheet.write(1, 0, 'Inventoried Location', style)
        worksheet.write(2, 0, 'Force Accounting Date', style)
        worksheet.write(3, 0, 'Journal', style)
        worksheet.write(4, 0, 'Company', style)
        worksheet.write(5, 0, '', style)
        worksheet.write(6, 0, 'Product', style)
        worksheet.write(6, 1, 'UoM', style)
        worksheet.write(6, 2, 'Location', style)
        worksheet.write(6, 3, 'Lot/Serial Number', style)
        worksheet.write(6, 4, 'Real Quantity', style)
        worksheet.write(6, 5, 'Unit Price', style)
        worksheet.write(6, 6, 'Company', style)
        worksheet.write(6, 7, 'Account code', style)

        fp = StringIO()
        workbook.save(fp)
        export_xls = self.env['full.inv.adjustment.import'].create(
            {'export_file': base64.encodestring(fp.getvalue()), 'export_name': file_name, 'is_export': True})
        fp.close()
        return {
            'view_mode': 'form',
            'res_id': export_xls.id,
            'res_model': 'full.inv.adjustment.import',
            'view_type': 'form',
            'type': 'ir.actions.act_window',
            'context': self._context,
            'target': 'new',
        }

    @api.multi
    def get_file_info(self):
        xls_data = base64.decodestring(self.import_file)
        temp_path = tempfile.gettempdir()
        file_path = os.path.join(temp_path, self.import_name)
        fp = open(file_path, 'wb+')
        fp.write(xls_data)
        fp.close()
        if not self.import_name.endswith('.xls'):
            raise ValidationError('Incorrect file format!')
        data = open_workbook(file_path, logfile=open(os.devnull, 'w'))
        return data


    @api.multi
    def import_inv_adjustment(self):
        workbook = self.get_file_info()
        for sheet in workbook.sheets():
            vals = {}
            for count in range(4):
                row = sheet.row_values(count)
                if row[0] == 'Inventory Reference':
                    vals['name'] = row[1]
                if row[0] == 'Force Accounting Date':
                    force_date = datetime.strptime(str(row[1]), "%Y-%m-%d %H:%M:%S").strftime(DEFAULT_SERVER_DATETIME_FORMAT)
                    vals['force_accounting_date'] = self.convert_to_utc(force_date)

                if row[0] == 'Inventoried Location':
                    location = str(row[1])
                    # if len(location) == 2:
                    #     nest_parent_id = self.env['stock.location'].search([('name', '=', location[0])], limit=1).id
                    #     main_location = location[1]
                    # else:
                    #     nest_parent_id = False
                    #     main_location = location[0]
                    main_location_id = self.env['stock.location'].search(
                        [('complete_name', '=', location)], limit=1).id
                    vals['location_id'] = main_location_id or False

                if row[0] == 'Journal':
                    journal_id = self.env['account.journal'].search([('name', '=', row[1])], limit=1)
                    vals['journal_id'] = journal_id.id
                if row[0] == 'Company':
                    company_id = self.env['res.company'].search([('name', '=', row[1])], limit=1)
                    vals['company_id'] = company_id.id
            line_list = []
            for count in range(7,sheet.nrows):
                line_vals = {}
                line = sheet.row_values(count)
                location = str(line[2])
                # if len(location) == 2:
                #     parent_id = self.env['stock.location'].search([('name', '=', location[0])], limit=1).id
                #     main_location = location[1]
                # else:
                #     parent_id = False
                #     main_location = location[0]
                if line[0]:
                    p_id = int(line[0])
                else:
                    p_id = False
                product_ids = self.env['product.product'].search([('id', '=', p_id)])
                uom_ids = self.env['product.uom'].search([('name', '=', line[1])])
                location_id = self.env['stock.location'].search([('complete_name', '=', location)])
                serial_number = line[3]
                if isinstance(line[3],float):
                    serial_number = str(int(line[3]))
                lot_id = self.env['stock.production.lot'].search([('name', '=', serial_number)],limit=1)
                if not lot_id and line[3]:
                    lot_id = self.env['stock.production.lot'].create({
                        'name'          : serial_number,
                        'product_id'    : product_ids.id
                    })
                try:
                    if line[8] and lot_id:
                        expire_date = datetime.strptime(str(line[8]), "%Y-%m-%d %H:%M:%S").strftime(DEFAULT_SERVER_DATETIME_FORMAT)
                        lot_id.write({'use_date': self.convert_to_utc(expire_date)})
                except:
                    pass
                account_id = self.env['account.account'].search(
                    [('code', '=', str(line[7])), ('company_id.name', '=', str(line[6]))], limit=1)

                line_vals['product_id'] = product_ids[0].id if product_ids else False
                line_vals['product_uom_id'] = uom_ids[0].id if uom_ids else False
                line_vals['location_id'] = location_id[0].id if location_id else False
                line_vals['prod_lot_id'] = lot_id[0].id if lot_id else False
                line_vals['product_qty'] = line[4]
                line_vals['unit_price'] = line[5]
                line_vals['adjustment_column'] = account_id[0].id if account_id else False
                line_list.append((0,0,line_vals))
            vals['line_ids'] = line_list
            vals['date'] = datetime.now()
            vals['new_price'] = True
            vals['filter'] = 'partial'
            stock_inventory_id = self.env['stock.inventory'].create(vals)
            stock_inventory_id.prepare_inventory()
        return True

    def convert_to_utc(self, date):
        timezone_tz = 'Asia/Kolkata'
        if self.env.user and self.env.user.tz:
            timezone_tz = self.env.user.tz
        else:
            timezone_tz = 'Asia/Kolkata'
        date_from = datetime.strptime(date,DEFAULT_SERVER_DATETIME_FORMAT).replace(tzinfo=tz.gettz(timezone_tz)).astimezone(tz.tzutc())
        return date_from.strftime(DEFAULT_SERVER_DATETIME_FORMAT)

full_inv_adjustment_import()