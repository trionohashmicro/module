# -*- coding: utf-8 -*-
{
    'name': 'Full Inventory Adjustment Import',
    'version': '1.0',
    'summary': 'Setup to import/download inventory adjustment',
    'description': 'Module includes setup to import/download inventory adjustment using xls format.',
    'author': 'Hashmicro/Antsyz-Kannan',
    'website': 'www.hashmicro.com',
    'category': 'Warehouse',
    'depends': ['full_inv_adjustment'],
    'data':[
        'wizard/full_inv_adjustment_import_view.xml',
    ],
    'installable': True,
    'application': True,
}
