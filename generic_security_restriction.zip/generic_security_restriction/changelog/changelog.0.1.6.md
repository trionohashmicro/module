#### Version 0.1.6
- Added the ability to hide a stat button witch includes the selected field.
 